<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!--
	Design by Free CSS Templates
	http://www.freecsstemplates.org
	Released for free under a Creative Commons Attribution 2.5 License

	Name: Tastelessly
	Description: A very light design suitable for community sites and blogs.
	Version: 1.0
	Released: 20080122
-->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<title>OntoLP | Portal de Ontologias</title>
	<link href="folha.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>

<?php include 'inc/topo.php' ?>

<hr />

<div id="page">
	
	<div id="content">
		<div class="post">
			<h1 class="title">Workshop Programme </h1>
			<div class="entry">
				<h2>Thursday (Sept 10) </h2>
                <p><b>8:00 ~ 10:00 - </b> Mesa redonda - Desafios da pesquisa em ontologias:
				<ul>
				<li><b>Fred Freitas: </b>Ontologias e Web Semântica</li>
				<li><b>Mara Abel: </b>Ontologias, representação do conhecimento e resolução de problemas</li>
				<li><b>Giancarlo Guizzardi: </b>Ontologias de Fundamentação e Qualidade de Modelos</li>
				<li><b>Renata Vieira: </b>Ontologias e língua portuguesa</li>
				</ul>
				</p>
                <p><b>10:00 ~ 10:30 - </b> Coffee break</p>
				<p><b>10:30 ~ 12:00 - </b>Apresentação e discussão das ontologias:
				<ul>
				<li><b>PetroGrapher: uma ontologia para Petrografia Sedimentar</b><br>
				Mara Abel, Luiz Fernando De Ros, Laura Siveira Mastella, Luis Álvaro Lima Silva, <br>
				Sandro Rama Fiorini, Eduardo Castro, Felipe Ingletto Victoreti<br>
				<i>Instituto de Informática da UFRGS</i></li>

				<li><b>Stimuli: uma ontologia para o paradigma de Equivalência de Estímulos</b><br>
				Rodrigo E. Bela, Marilde T. P. Santos, Mauro Biajiz<br>
				<i>Departamento de Computação da UFSCar</i></li>

				<li><b>Um Modelo para Redes de Conhecimento Científico</b><br>
				Daniel C. de Paiva, Marcos L. Mucheroni, Marcio L. Netto<br>
				<i>Escola Politécnica - Departamento de Engenharia de Sistemas Eletrônicos da USP, <br>
				Escola de Comunicação e Artes, Departamento de Biblioteconomia e Documentação da USP</i></li></ul></p>
				
				<p><b>12:00 ~ 12:30 - </b> Discussões gerais </p>
				
				<p><b>12:30 ~ 14:00 - </b> Almoço </p>
				
				<p><b>14:00 ~ 15:30 - </b>Apresentação e discussão das ontologias:
				<ul>
				<li><b>Teste do Linux: uma formalização baseada na Ontologia SwTOi</b><br>
				Daniella R. Bezerra, Afonso R. Costa Jr., Karla Okada.<br>
				<i>Fundação Paulo Feitoza – Manaus, Instituto Nokia de Tecnologia – Manaus.</i></li>

				<li><b>Privacidade e responsabilização: representação do domínio</b><br>
				Douglas da Silva, Mírian Bruckschen, Paulo Bridi, Roger Granada, Alexandre Agustini, <br>
				Renata Vieira, Caio Northfleet<br>
				<i>Faculdade de Informática da PUCRS, HP Brasil</i></li>

				<li><b>Um Ontologia de Domínio para Estratigrafia Sedimentar Baseada em Primitivas Conceituais e Pictóricas</b><br>
				Alexandre Lorenzatti, Mara Abel, Bruno Romeu Nunes, Claiton M. S. Scherer.<br>
				<i>Instituto de informática da UFRGS, Instituto de Geociências da UFRGS</i></li></ul></p>
                
				<p><b>15:30 ~ 16:00 - </b> Discussões gerais e encerramento </p>
				
				<p><b>16:00 ~ 16:30 - </b> Coffee break </p>
				
				<p><b>16:30 ~ 17:30 - </b> Painel STIL </p>
				
				<p><b>17:30 ~ 18:30 - </b> Reunião da comunidade de PLN </p>
				
				<p><b>18:30 ~ 20:00 - </b> Reunião da CEPLN-SBC </p>
				
				<p><b>20:00 - </b> Jantar da conferência </p>
                    
                
			</div>			
		</div>
	</div>
	<?php include 'stil.php' ?>
	
	<div style="clear:both;">&nbsp;</div>
</div>

<hr />

<div id="footer">
	<p>&copy;2007 All Rights Reserved.&nbsp;&bull;&nbsp; Designed by <a href="http://www.freecsstemplates.org/" target="_blank">Free CSS Templates</a>.</p>
</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5307915-1");
pageTracker._trackPageview();
</script>

</body>
</html>