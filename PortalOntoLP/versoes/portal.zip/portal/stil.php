<div id="sidebar1" class="sidebar">
	<ul>
		<li id="recent-posts">
			<h2>STIL</h2>
			<ul>
				<li>
				
					<h3><a href="http://www.inf.ufrgs.br/stil09/" target="_blank">STIL 2009 - 7º Simpósio Brasileiro em Tecnologia da Informação e da Linguagem Humana</a> <br /></h3>
					<p align="left">Data: 07/09/09 - 11/09/09</p>					
					
					
					
				</li>
			</ul>
		</li>
	</ul>
</div>