<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!--
	Design by Free CSS Templates
	http://www.freecsstemplates.org
	Released for free under a Creative Commons Attribution 2.5 License

	Name: Tastelessly
	Description: A very light design suitable for community sites and blogs.
	Version: 1.0
	Released: 20080122
-->

<?php

	include_once('class.phpmailer.php');
	$mail   = new PHPMailer();

	$acao = $_GET["acao"];
	
	if ($acao == "enviar") {
	
		
		
		$msg 	.= "<p>Nome: ".$_POST["q0"]."<p>";
		$msg 	.= "<p>E-mail: ".$_POST["q1"]."<p>";
		$msg	.= "<p>Grupo: ".$_POST["q2"]."<p>";
		$msg	.= "<p>Instituição: ".$_POST["q3"]."<p>";
		$msg	.= "<p>Projeto: ".$_POST["q4"]."<p> ";
		$msg	.= "<p>Site: ".$_POST["q5"]."<p>";
		$msg	.= "<p>Material para disponibilizar: ".$_POST["q6"]."<p>";
		$msg	.= "<p>Tipo material: <p>";
		foreach($_POST["q7"] as $q7)
		{
			$msg	.=   "- " . $q7 . "<BR>";
		}	
					//implode(' - ', $_POST["q7"])."\n";
		//$msg	.= "<p>Outro tipo de material: ".$_POST["q21"]."<p>";
		$msg  .= "<p>Detalhes da Ontologia:<p>";
		$msg	.= "<p>Título: ".$_POST["q8"]."<p>";
		$msg	.= "<p>Domínio: ".$_POST["q9"]."<p>";
		$msg	.= "<p>Idioma: ".$_POST["q10"]."<p>";
		$msg	.= "<p>Especialista do Domínio: ".$_POST["q24"]."<p>";
		$msg	.= "<p>Linguagem: ".$_POST["q11"]."<p>";
		$msg	.= "<p>Aplicação: ".$_POST["q12"]."<p>";
		$msg	.= "<p>Última Atualização: ".$_POST["q22"]."<p>";
		$msg	.= "<p>Ferramenta utilizada: ".$_POST["q23"]."<p>";
		$msg	.= "<p>URL: ".$_POST["q13"]."<p>";
		$msg  .= "<p>Detalhes da Ferramenta:<p>";
		$msg	.= "<p>Nome: ".$_POST["q14"]."<p>";
		$msg	.= "<p>Linguagem: ".$_POST["q15"]."<p>";
		$msg	.= "<p>Propósito: ".$_POST["q16"]."<p>";
		$msg	.= "<p>Licença: ".$_POST["q17"]."<p>";
		$msg	.= "<p>URL: ".$_POST["q18"]."<p>";
		$msg  .= "<p>Detalhes do Recurso:<p>";
		$msg	.= "<p>Descrição: ".$_POST["21"]."<p>";
		$msg	.= "<p>URL: ".$_POST["q22"]."<p>";
		$msg	.= "<p>Referência: ".$_POST["q19"]."<p>";
		$msg	.= "<p>Comentários: ".$_POST["q20"]."<p>";
		
		
		
		mail('portal.ontologia@gmail.com', 'Contato através do site', $msg);
		
		mail($admmail, $subject, $mail_body, $header);
		
		$mail->IsSMTP(); // telling the class to use SMTP
		
		$mail->SMTPAuth = true; // turn on SMTP authentication
		$mail->Username = "portal.ontologia@gmail.com"; // SMTP username
		$mail->Password = "labontolp12"; // SMTP password
		$webmaster_email = "portal.ontologia@gmail.com"; //Reply to this email ID
		$email="portal.ontologia@gmail.com"; // Recipients email ID
		$name="Portal de Ontologias - OntoLP"; // Recipient's name
		$mail->From = $webmaster_email;
		// $mail->FromName = "Webmaster";
		
		
		
		
		
		
		// $mail->Host       = "smtp.pucrs.br"; // SMTP server

		// $mail->From       = "ontolp@pucrs.br";
		$mail->FromName   = "Portal de Ontologia";

		$mail->Subject    = "Contato através do site";
		$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

		$mail->MsgHTML($msg);

		$mail->AddAddress("portal.ontologia@gmail.com", "Portal de Ontologia");

		
		
		$targetdir = '/var/tmp/';
   // $mail->AddAttachment($targetdir.$_FILES['arquivoOnto']['name']);
	//$mail->AddAttachment($targetdir.$_FILES['arquivoAbst']['name']);
	//,$_FILES["arquivoAbst"]);             // attachment

	
	function file_upload_error_message($error_code) {
    switch ($error_code) {
        case UPLOAD_ERR_INI_SIZE:
            return 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
        case UPLOAD_ERR_FORM_SIZE:
            return 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
        case UPLOAD_ERR_PARTIAL:
            return 'The uploaded file was only partially uploaded';
        case UPLOAD_ERR_NO_FILE:
            return 'No file was uploaded';
        case UPLOAD_ERR_NO_TMP_DIR:
            return 'Missing a temporary folder';
        case UPLOAD_ERR_CANT_WRITE:
            return 'Failed to write file to disk';
        case UPLOAD_ERR_EXTENSION:
            return 'File upload stopped by extension';
        default:
            return 'Unknown upload error'; 
	}
	}
	
	         //'/home/proj/ontolp/public_html/upload.';
//	$uploaddir = './home/proj/ontolp/public_html/upload';									//'/var/tmp/';
	//$uploadfile = $uploaddir . $_FILES['arquivoAbst']['error'];
	
	
	if (is_uploaded_file($_FILES['arquivoOnto']['tmp_name'])) {
		echo "O arquivo ". $_FILES['arquivoOnto']['tmp_name'] ." foi enviado com sucesso.\n";
		move_uploaded_file($_FILES['arquivoOnto']['tmp_name'], $targetdir.$_FILES['arquivoOnto']['name']);
		echo "Mostrando o conteúdo\n";
		//readfile($targetdir.$_FILES['arquivoOnto']['name']);
		echo $targetdir.$_FILES['arquivoOnto']['name'];
		echo $targetdir.$_FILES['arquivoOnto']['tmp_name'];
	} else {
		echo "Possível ataque de envio de arquivo: ";
		echo "nome do arquivo '". $_FILES['arquivoOnto']['tmp_name'] . "'.";
	}
	
		
	if (is_uploaded_file($_FILES['arquivoFer']['tmp_name'])) {
		echo "O arquivo ". $_FILES['arquivoFer']['tmp_name'] ." foi enviado com sucesso.\n";
		move_uploaded_file($_FILES['arquivoFer']['tmp_name'], $targetdir.$_FILES['arquivoFer']['name']);
		echo "Mostrando o conteúdo\n";
		//readfile($targetdir.$_FILES['arquivoFer']['name']);
		echo $targetdir.$_FILES['arquivoFer']['name'];
		echo $targetdir.$_FILES['arquivoFer']['tmp_name'];
	} else {
		echo "Possível ataque de envio de arquivo: ";
		echo "nome do arquivo '". $_FILES['arquivoFer']['tmp_name'] . "'.";
	}
	
	
	if (is_uploaded_file($_FILES['arquivoRec']['tmp_name'])) {
		echo "O arquivo ". $_FILES['arquivoRec']['tmp_name'] ." foi enviado com sucesso.\n";
		move_uploaded_file($_FILES['arquivoRec']['tmp_name'], $targetdir.$_FILES['arquivoRec']['name']);
		echo "Mostrando o conteúdo\n";
		//readfile($targetdir.$_FILES['arquivoRec']['name']);
		echo $targetdir.$_FILES['arquivoRec']['name'];
		echo $targetdir.$_FILES['arquivoRec']['tmp_name'];
	} else {
		echo "Possível ataque de envio de arquivo: ";
		echo "nome do arquivo '". $_FILES['arquivoRec']['tmp_name'] . "'.";
	}
	
	$mail->AddAttachment($targetdir.$_FILES['arquivoOnto']['name']);
	$mail->AddAttachment($targetdir.$_FILES['arquivoFer']['name']);
	$mail->AddAttachment($targetdir.$_FILES['arquivoRec']['name']);
		
	
		if(!$mail->Send()) {
			echo "Mailer Error: " . $mail->ErrorInfo;
		} else {
			//echo "Message sent!";}
			//echo "<a href='obrigado.php'>";}
			echo "<script language='JavaScript'> window.location.replace('obrigado.php');
			self.location = 'obrigado.php'; </script>";}
		
	

}



?>


<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<title>OntoLP | Portal de Ontologias</title>
	<link href="folha.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>

<script type="text/javascript" language=JavaScript>
    function divManager(idDiv, obj) {
		var div = document.getElementById(idDiv);
		if (obj.checked) {
			div.style.display = "";
		} else {
			div.style.display = "none";
		}
	}
	
	function frmContatoValidate() {
		if (document.frmContato.q0.value.length == 0) {
			alert("Por favor, informe o valor para o campo Nome.");
			document.frmContato.q0.focus();
			return false;
		}

		if (document.frmContato.q1.value.length == 0) {
			alert("Por favor, informe o valor para o campo E-mail.");
			document.frmContato.q1.focus();
			return false;
		}

		if (document.frmContato.q3.value.length == 0) {
			alert("Por favor, informe o valor para o campo Instituiçao.");
			document.frmContato.q3.focus();
			return false;
		}

		return true;
	}
	
	function soh_letra(c)
    {
        if ((c>64 && c<91) || (c>96 && c<123) || (c==32)){
            event.returnValue=1;
        }else{
            event.returnValue=0
            alert("Caracter Inválido")
        }
    }
	
</script>


<?php include 'inc/topo.php' ?>

<hr />

<div id="page">
	
	<div id="content">
		<div class="post">
			<h1 class="title">Contato</h1>
			<div class="entry">
			
				<table width="100%" cellpadding="2" cellspacing="0" class="tbmain">
					<tr>
						<td class="topleft" width="10" height="10">&nbsp;</td>
						<td class="topmid">&nbsp;</td>
						<td class="topright" width="10" height="10">&nbsp;</td>
					</tr>
					<tr>
						<td class="midleft" width="10">&nbsp;&nbsp;&nbsp;</td>
						<td class="midmid" valign="top">
							<form enctype="multipart/form-data" action="contato.php?acao=enviar" method="post" name="frmContato"  onsubmit="return frmContatoValidate()">
							

								<div id="main">

									<table width="520" cellpadding="5" cellspacing="0">
										<tr>
											<td width="100" class="left" ><label>Nome <span class="required">*</span></label></td>
											<td width="244" class="right"><input type="text" size="40" name="q0" class="text" value="" id="q0" onblur="validate(this,'Required')" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="100" class="left" ><label>E-mail <span class="required">*</span></label></td>
											<td class="right"><input type="text" size="40" name="q1" class="text" value="" id="q1" onblur="validate(this,'Email')" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="100" class="left" ><label>Grupo</label></td>
											<td class="right"><input type="text" size="40" name="q2" class="text" value="" id="q2" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="100" class="left" ><label>Instituição<span class="required">*</span></label></td>
											<td class="right"><input type="text" size="40" name="q3" class="text" value="" id="q3" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="100" class="left" ><label>Projeto</label></td>
											<td class="right"><input type="text" size="40" name="q4" class="text" value="" id="q4" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="100" class="left" ><label>Site</label></td>
											<td class="right"><input type="text" size="40" name="q5" class="text" value="" id="q5" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="100" class="left" valign="top" ><label>Possui algum material que gostaria de disponibilizar no portal?</label></td>
											<td class="right">
												<input type="radio" class="other" name="q6" id="q6S" value="Sim" /><label class="left">Sim</label>
												<input type="radio" class="other" name="q6" id="q6N" value="Não" /><label class="left">Não</label><br />
											</td>
										</tr>
										<tr>
											<td width="100" class="left" valign="top" ><label>Tipo do recurso:</label></td>
											<td valign="top" class="right">
												<input name="q7[]" type="checkbox" class="other" id="q71" onclick="divManager('divOntologia', this);" value="Ontologia"/>
									      <label class="left">Ontologia</label><br />
												<input type="checkbox"  name="q7[]" class="other" id="q72" value="Ferramenta" onclick="divManager('divFerramenta', this);"/><label class="left">Ferramenta</label><br />
												<input type="checkbox"  name="q7[]" class="other" id="q73" value="Outro"  onclick="divManager('divOutro', this);" /><label class="left">Outro</label><br />
											</td>
										</tr>
										
										</table>
									<div id="divOntologia" style="display:none;">
									<table width="520" cellpadding="5" cellspacing="0">
										<tr>
											<td colspan="2" class="left"><h2>Detalhes da Ontologia:</h2></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>Título</label></td>
											<td class="right"><input type="text" size="40" name="q8" class="text" value="" id="q8" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="180" class="left"><label><a href="#" class="dcontexto">Domínio<span>Informe o domínio da Ontologia.</span></a><span class="required">*</span></label></td>
											<td class="right"><input type="text" size="40" name="q9" class="text" value="" id="q9" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>Idioma</label></td>
											<td class="right"><input type="text" size="40" name="q10" class="text" value="" id="q10"  maxlength="100" maxsize="100" /></td>
										</tr>
										 <tr>
											<td width="180" class="left"><label><a href="#" class="dcontexto">Especialista do Domínio<span>Nome completo do especialista principal da Ontologia.</span></a><span class="required">*</span></label></td>
											<td class="right"><input type="text" size="40" name="q24" class="text" value="" id="q24"  maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>Linguagem</label></td>
											<td class="right"><input type="text" size="40" name="q11" class="text" value="" id="q11" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>Aplicação</label></td>
											<td class="right"><input type="text" size="40" name="q12" class="text" value="" id="q12" maxlength="300" maxsize="300" /></td>
										</tr>
										
										<tr>
											<td width="180" class="left"><label><a href="#" class="dcontexto">Última 		Atualização (mm/aaaa)<span>Informe a data da última atualização da Ontologia.</span></a><span class="required">*</span></label></td>
											<td class="right"><input type="text" size="40" name="q22" class="text" value="" id="q22" maxlength="100" maxsize="100"/></td>
										</tr>
										
										<tr>
											<td width="180" class="left"><label><a href="#" class="dcontexto">Ferramenta Utilizada<span>Caso tenha sido utilizada alguma ferramenta na construção da ontologia informe o nome e a versão</span></a></label></td>
											<td class="right"><input type="text" size="40" name="q23" class="text" value="" id="q23" maxlength="100" maxsize="100"/></td>
										</tr>
										
										<tr>
											<td width="252" class="left" ><label>URL</label></td>
											<td class="right"><input type="text" size="40" name="q13" class="text" value="" id="q13" maxlength="100" maxsize="100" /></td>
										</tr>
										
								        <tr>
											<td colspan="2" class="left"><h2>Envio da Ontologia:</h2></td>
										</tr>
										<tr>
											<td width="60" class="left" valign="top" ><label><input name="arquivoOnto" id="arquivoOnto" type="file"/></label></td>
											<td class="right">&nbsp;</td>
										</tr>
								
										
										</table>
									</div>
									<div id="divFerramenta" style="display:none;">
									<table width="520" cellpadding="5" cellspacing="0">
										
										<tr>
											<td colspan="2" class="left"><h2>Detalhes da Ferramenta:</h2></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>Nome</label></td>
											<td class="right"><input type="text" size="40" name="q14" class="text" value="" id="q14" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>Linguagem</label></td>
											<td class="right"><input type="text" size="40" name="q15" class="text" value="" id="q15" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>Propósito</label></td>
											<td class="right"><input type="text" size="40" name="q16" class="text" value="" id="q16"  maxlength="300" maxsize="300" /></td>
										</tr>
										
										<tr>
											<td width="252" class="left" ><label>Licença</label></td>
											<td class="right"><input type="text" size="40" name="q17" class="text" value="" id="q17" maxlength="100" maxsize="100" /></td>
										</tr>
										<tr>
											<td width="252" class="left" ><label>URL</label></td>
											<td class="right"><input type="text" size="40" name="q18" class="text" value="" id="q18" maxlength="100" maxsize="100" /></td>
										</tr>
										
										<tr>
											<td colspan="2" class="left"><h2>Envio da Ferramenta:</h2></td>
										</tr>
										<tr>
											<td width="60" class="left" valign="top" ><label><input name="arquivoFer" id="arquivoFer" type="file"/></label></td>
											<td class="right">&nbsp;</td>
										</tr>
										
										</table>		
								</div>
								
								<div id="divOutro" style="display:none;">
									<table width="520" cellpadding="5" cellspacing="0">
										<tr>
											<td colspan="2" class="left" ><h2>Detalhes do Recurso:</h2></td>
										</tr>
										<tr>
											<td width="252" class="left" valign="top"><label>Descrição do Recurso</label></td>
											<td class="right"><textarea cols="38" rows="3" name="q21" class="text" id="q19" ></textarea></td>
										</tr>
										<tr>
											<td class="right">&nbsp;</td>
										</tr>
																				
										<tr>
											<td width="252" class="left" ><label>URL do Recurso</label></td>
											<td class="right"><input type="text" size="38" name="q22" class="text" value="" id="q13" maxlength="100" maxsize="100" /></td>
										</tr>
										
										<tr>
											<td colspan="2" class="left"><h2>Envio do Recurso:</h2></td>
										</tr>
										<tr>
											<td width="60" class="left" valign="top" ><label><input name="arquivoRec" id="arquivoRec" type="file"/></label></td>
										</tr>
										</table>
									</div>
								
									<table width="520" cellpadding="5" cellspacing="0">
										<tr>
											<td colspan="2" class="left"><h2>Referências</h2></td>
										</tr>
										
										<tr>
											<td>&nbsp;</td>
											<td>&nbsp;</td>
										</tr>
										<tr>
											<td width="252" class="left" valign="top"><label>Existe alguma referência bibliográfica que gostaria de associar aos recursos disponibilizados?</label></td>
											<td class="right"><textarea cols="38" rows="3" name="q19" class="text" id="q19" ></textarea></td>
										</tr>
										<tr>
											<td>&nbsp;</td>
											<td>&nbsp;</td>
										</tr>
										<tr>
											<td width="252" class="left" valign="top" ><label>Comentários</label></td>
											<td class="right"><textarea cols="38" rows="5" name="q20" class="text" id="q20" ></textarea></td>
										</tr>
										<tr>
											<td>&nbsp;</td>
																					
										</tr>
										<tr>
											<td width="100" class="left">&nbsp;</td>
											
											<td class="right">
												<input type="submit" class="btn" value="Enviar" /><input name="Reset" type="reset" class="btn" value="Limpar" />
											</td>
										</tr>
										<tr >
											<td colspan="2" class="left" ><span class="required">*</span>campos obrigatórios</td>
										</tr>
										
									</table>
								
				
							</form>
						</td>
						<td class="midright" width="10">&nbsp;&nbsp;&nbsp;</td>
					</tr>
					<tr>
						<td class="bottomleft" width="10" height="10">&nbsp;</td>
						<td class="bottommid">&nbsp;</td>
						<td class="bottomright" width="10" height="10">&nbsp;</td>
					</tr>
				</table>
				
				<blockquote>&nbsp;</blockquote>
			</div>
		</div>
	</div>
	
	<div style="clear: both;">&nbsp;</div>
</div>

<hr />

<div id="footer">
	<p>&copy;2007 All Rights Reserved.&nbsp;&bull;&nbsp; Designed by <a href="http://www.freecsstemplates.org/" target="_blank">Free CSS Templates</a>.</p>
</div>

</body>
</html>