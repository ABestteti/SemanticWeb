{
	employees: [
		{
			employeeId: 1,
			firstName: 'Joe',
			lastName: 'Smith',
			department: 'Management',
			title: 'CEO',
			telephone: '240-555-1287',
			office: 'DC'
		},{
			employeeId: 2,
			firstName: 'George',
			lastName: 'Loram',
			department: 'Sales',
			title: 'VP of Sales',
			telephone: '240-555-1287',
			office: 'DC'
		},{
			employeeId: 3,
			firstName: 'Sally',
			lastName: 'Beogagi',
			department: 'Human Resources',
			title: 'Senior Hiring Agent',
			telephone: '443-555-1220',
			office: 'MD'
		},{
			employeeId: 4,
			firstName: 'Billy',
			lastName: 'Diarmaid',
			department: 'Human Resources',
			title: 'Hiring Agent',
			telephone: '443-555-2890',
			office: 'MD'
		},{
			employeeId: 5,
			firstName: 'Bruno',
			lastName: 'Domingos',
			department: 'Technology',
			title: 'CTO',
			telephone: '443-555-2890',
			office: 'MD'
		}
	]
}