<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!--
	Design by Free CSS Templates
	http://www.freecsstemplates.org
	Released for free under a Creative Commons Attribution 2.5 License

	Name: Tastelessly
	Description: A very light design suitable for community sites and blogs.
	Version: 1.0
	Released: 20080122
-->

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<title>OntoLP | Portal de Ontologias</title>
	<link href="folha.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>

<?php include 'inc/topo.php' ?>

<hr />

<div id="page">
	
	<div id="content">
		<div class="post">
			<h1 class="title">I Portuguese and Multi-lingual Ontologies Workshop</h1>
			<div class="entry">
				<p align="justify">STIL Workshop on Portuguese and Multi-lingual Ontologies building, evaluation and reuse.</p>
                <p align="justify">This workshop welcomes the submission of ontologies and a corresponding abstract instead of full written papers related to
                    ontologies. In the submission process the authors should also answer aquestionnaire about the resource being submitted, such as:  What is the main purpose for the ontology? What is the related  reasoning
                process, which answers should it provide?</p>
                <p align="justify">The ontologies may be partial or under development.  There is no
                    constraint on the ontology format, on the formalism in which it is
                    implemented, on the domain it describes.  However, it is desirable
                    that they are written in Portuguese or that they include Portuguese
                translation of terms.</p>
                <p align="justify">Ontologies will be selected for discussion during the meeting at STIL
                    2009.  Questions regarding quality and reasoning capabilities will be
                    analysed and discussed with the engineers by a panel composed by
                Giancarlo Guizzardi, Mara Abel, and Renata Vieira.</p>
                <p align="justify">By gathering concrete examples, we hope to achieve a better
                    understanding of quality ontology design, providing feedback for
                    ontology practitioners as well as collecting and making available
                    Portuguese ontologies, providing resources for researchers in the area
                of ontologies and Portuguese language.</p>
                <p align="justify">The abstracts will be published in the workshop proceedings and the
                ontology itself will be made available through the OntoLP  web site.</p>
                <h3><p>Important dates:<br></h3>
                    Ontology submission: June 22 2009.<br>
                    Acceptance notification: July 20 2009.<br>
                Final abstract uploading: July 26 2009.<br></p>
                <p>
                    <h4>
                        <a href="contatoOficina.php">Click here for Ontology submission form.</a>
                    </h4>
                </p>
			</div>			
		</div>
	</div>
	
	<?php include 'inc/news.php' ?>
	
	<div style="clear:both;">&nbsp;</div>
</div>

<hr />

<div id="footer">
	<p>&copy;2007 All Rights Reserved.&nbsp;&bull;&nbsp; Designed by <a href="http://www.freecsstemplates.org/" target="_blank">Free CSS Templates</a>.</p>
</div>

<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
var pageTracker = _gat._getTracker("UA-5307915-1");
pageTracker._trackPageview();
</script>

</body>
</html>