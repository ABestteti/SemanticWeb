<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<!--
Design by Free CSS Templates
http://www.freecsstemplates.org
Released for free under a Creative Commons Attribution 2.5 License

Name: Tastelessly
Description: A very light design suitable for community sites and blogs.
Version: 1.0
Released: 20080122
-->

<?php

include_once('class.phpmailer.php');
$mail   = new PHPMailer();

$acao = $_GET["acao"];

if ($acao == "enviar") {

    /*$FileFormData = 'uploadedFiles/OntoLPUpload.xml';

    if (!($C=fopen($FileFormData,"w+"))) {
        echo 'Erro ao criar o arquivo de gravacão do formulário';
        exit;
    }

    fwrite($C,'<?xml version="1.0"?>'."\n");
    fwrite($C,'<OntoLP>'."\n");
    fwrite($C,'<nome>'                 . $_POST["q0"]  . '</nome>'."\n");
    fwrite($C,'<mail>'                 . $_POST["q1"]  . '</mail>'."\n");
    fwrite($C,'<instituicao>'          . $_POST["q2"]  . '</instituicao>'."\n");
    fwrite($C,'<grupo>'                . $_POST["q3"]  . '</grupo>'."\n");
    fwrite($C,'<projeto>'              . $_POST["q4"]  . '</projeto>'."\n");
    fwrite($C,'<site>'                 . $_POST["q5"]  . '</site>'."\n");
    fwrite($C,'<aplicacao>'            . $_POST["q6"]  . '</aplicacao>'."\n");
    fwrite($C,'<producaoCientifica>'   . $_POST["q7"]  . '</producaoCientifica>'."\n");
    fwrite($C,'<comentarios>'          . $_POST["q8"]  . '</comentarios>'."\n");
    fwrite($C,'<ontoAnoCronstrucao>'   . $_POST["q10"] . '</ontoAnoCronstrucao>'."\n");
    fwrite($C,'<ontoDominio>'          . $_POST["q11"] . '</ontoDominio>'."\n");
    fwrite($C,'<ontoLingua>'           . $_POST["q12"] . '</ontoLingua>'."\n");
    fwrite($C,'<ontoNumEspecialistas>' . $_POST["q13"] . '</ontoNumEspecialistas>'."\n");
    fwrite($C,'<ontoLinguagem>'        . $_POST["q14"] . '</ontoLinguagem>'."\n");
    fwrite($C,'<ontoURL>'              . $_POST["q15"] . '</ontoURL>'."\n");
    fwrite($C,'<ferrNome>'             . $_POST["q16"] . '</ferrNome>'."\n");
    fwrite($C,'<ferrLinguagem>'        . $_POST["q17"] . '</ferrLinguagem>'."\n");
    fwrite($C,'<ferrLicenca>'          . $_POST["q18"] . '</ferrLicenca>'."\n");
    fwrite($C,'<outroDescRecurso>'     . $_POST["q19"] . '</outroDescRecurso>'."\n");
    fwrite($C,'</OntoLP>'."\n");

    fclose($C);
     */

    $msg .= "<p>Nome: ".$_POST["q0"]."<p>";
    $msg .= "<p>E-mail: ".$_POST["q1"]."<p>";
    $msg .= "<p>Instituição: ".$_POST["q2"]."<p>";
    $msg .= "<p>Projeto: ".$_POST["q3"]."<p> ";
    $msg .= "<p>Site: ".$_POST["q4"]."<p>";
    $msg .= "<p>Aplicação: ".$_POST["q5"]."<p>";
    $msg .= "<p>Publicação: ".$_POST["q6"]."<p>";
    $msg .= "<p>Comentários: ".$_POST["q7"]."<p>";
    $msg .= "<p>Última Atualização: ".$_POST["q8"]."<p>";
    $msg .= "<p>Domínio: ".$_POST["q9"]."<p>";
    $msg .= "<p>Idioma: ".$_POST["q10"]."<p>";
    $msg .= "<p>Especialista do Domínio: ".$_POST["q11"]."<p>";
    $msg .= "<p>Linguagem: ".$_POST["q12"]."<p>";
    $msg .= "<p>URL: ".$_POST["q13"]."<p>";

    mail('portal.ontologia@gmail.com', 'Oficina - Submissão de Trabalho', $msg);

    mail($admmail, $subject, $mail_body, $header);

    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->Host       = "smtp.pucrs.br"; // SMTP server

    $mail->From       = "ontolp@pucrs.br";
    $mail->FromName   = "Oficina - Portal de Ontologia";

    $mail->Subject    = "Portal de Ontologia: Oficina - Submissão de Trabalho";
    $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

    $mail->MsgHTML($msg);

    $mail->AddAddress("portal.ontologia@gmail.com", "Oficina - Portal de Ontologia");

    //$mail->AddAttachment("images/phpmailer.gif");             // attachment

    if(!$mail->Send()) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }
    else {
        echo "<script language='JavaScript'> window.location.replace('obrigado.php');
            self.location = 'obrigado.php'; </script>";
    }
}
?>


<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <title>OntoLP | Portal de Ontologias</title>
        <link href="folha.css" rel="stylesheet" type="text/css" media="screen" />
    </head>

    <body>

        <script type="text/javascript" language=JavaScript>
            function divManager(idDiv, obj) {
                var div = document.getElementById(idDiv);
                if (obj.checked) {
                    div.style.display = "";
                } else {
                    div.style.display = "none";
                }
            }

            function frmContatoValidate() {
                if (document.frmContato.q0.value.length == 0) {
                    alert("Por favor, informe o valor para o campo Nome.");
                    document.frmContato.q0.focus();
                    return false;
                }

                if (document.frmContato.q1.value.length == 0) {
                    alert("Por favor, informe o valor para o campo E-mail.");
                    document.frmContato.q1.focus();
                    return false;
                }

                if (document.frmContato.q2.value.length == 0) {
                    alert("Por favor, informe o valor para o campo Instituiçao.");
                    document.frmContato.q2.focus();
                    return false;
                }

                if (document.frmContato.q8.value.length == 0) {
                    alert("Por favor, informe o valor para o campo Última Atuliazação.");
                    document.frmContato.q8.focus();
                    return false;
                }

                if (document.frmContato.q9.value.length == 0) {
                    alert("Por favor, informe o valor para o Domínio.");
                    document.frmContato.q9.focus();
                    return false;
                }

                if (document.frmContato.q11.value.length == 0) {
                    alert("Por favor, informe o valor para o campo Especialista do Domínio.");
                    document.frmContato.q11.focus();
                    return false;
                }

                if (document.frmContato.arquivoOnto.value.length == 0 &&
                    document.frmContato.arquivoAbst.value.length == 0) {
                    alert("Por favor, informe pelo menos um nome de arquivo para envio.");
                    document.frmContato.arquivoOnto.focus();
                    return false;
                }

                return true;
            }
        </script>


<?php include 'inc/topo.php' ?>

        <hr />

        <div id="page">

            <div id="content">
                <div class="post">
                    <h1 class="title">Contato Oficina</h1>
                    <div class="entry">

                        <table width="100%" cellpadding="2" cellspacing="0" class="tbmain">
                            <tr>
                                <td class="topleft" width="10" height="10">&nbsp;</td>
                                <td class="topmid">&nbsp;</td>
                                <td class="topright" width="10" height="10">&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="midleft" width="10">&nbsp;&nbsp;&nbsp;</td>
                                <td class="midmid" valign="top">
                                    <form action="contatoOficina.php?acao=enviar" method="post" name="frmContato" onSubmit="return frmContatoValidate()">
                                        <div id="main">
                                        <table width="520" cellpadding="5" cellspacing="0">
                                            <tr>
                                                <td width="100" class="left" title="Nome completo da pessoa responsável pelo preenchimento deste formulário." ><label>Nome <span class="required">*</span></label></td>
                                                <td width="244" class="right"><input type="text" size="50" name="q0" class="text" value="" id="q0"
                                                                                     onblur="validate(this,'Required')" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" title="E-mail válido da pessoa responsável pelo preenchimento deste formulário."><label>E-mail <span class="required">*</span></label></td>
                                                <td class="right"><input type="text" size="50" name="q1" class="text" value="" id="q1"
                                                                         onblur="validate(this,'Email')" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left"title="Nome da instituição a qual a pessoa responsável está vinculada." ><label>Instituição <span class="required">*</span></label></td>
                                                <td class="right"><input type="text" size="50" name="q2" class="text" value="" id="q2" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" title="Informe o nome do projeto o qual a Ontologia faz parte."><label>Projeto</label></td>
                                                <td class="right"><input type="text" size="50" name="q3" class="text" value="" id="q3" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" title="Endereço da página web do projeto."><label>Site</label></td>
                                                <td class="right"><input type="text" size="50" name="q4" class="text" value="" id="q4" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" title="Descrição da aplicação."><label>Aplicação</label></td>
                                                <td class="right"><textarea cols="50" rows="3" name="q5" class="text" id="q5" ></textarea></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" valign="top" title="Publicações relacionadas ao projeto e à Ontologia."><label>Publicação</label></td>
                                                <td class="right"><textarea cols="50" rows="3" name="q6" class="text" id="q6" ></textarea></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" valign="top" title="Descrições complementares, que julgues relevante."><label>Comentários</label></td>
                                                <td class="right"><textarea cols="50" rows="3" name="q7" class="text" id="q7" ></textarea></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="left"><h2>Detalhes da Ontologia:</h2></td>
                                            </tr>
                                            <tr>
                                                <td width="252" class="left" title="Informe a data da última atualização da Ontologia."><label>Última Atualização (mm/aaaa) <span class="required">*</span></label></td>
                                                <td class="right"><input type="text" size="50" name="q8" class="text" value="" id="q8" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="252" class="left" title="Informe o domínio da Ontologia."><label>Domínio <span class="required">*</span></label></td>
                                                <td class="right"><input type="text" size="50" name="q9" class="text" value="" id="q9" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="252" class="left" title="Informe em que idioma a Ontologia foi construída (por exemplo: Português, Espanhol, Inglês)."><label>Idioma</label></td>
                                                <td class="right"><input type="text" size="50" name="q10" class="text" value="" id="q10"  maxlength="100" maxsize="100" /> </td>
                                            </tr>
                                            <tr>
                                                <td width="252" class="left" title="Nome completo do especialista principal da Ontologia. "><label>Especialista do Domínio  <span class="required">*</span></label></td>
                                                <td class="right"><input type="text" size="50" name="q11" class="text" value="" id="q11"  maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="252" class="left" title="Informe qual liguagem utilizada para a construção da Ontologia (por exemplo: RDF, OWL)."><label>Linguagem</label></td>
                                                <td class="right"><input type="text" size="50" name="q12" class="text" value="" id="q12" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td width="252" class="left" title="Informe a URL em que a Ontologia encontra-se disponível."><label>URL</label></td>
                                                <td class="right"><input type="text" size="50" name="q13" class="text" value="" id="q13" maxlength="100" maxsize="100" /></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="left"><h2>Envio da Ontologia:</h2></td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" valign="top" ><label><input name="arquivoOnto" type="file" /></label></td>
                                                <td class="right">&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" class="left"><h2>Envio do Resumo:</h2></td>
                                            </tr>
                                            <tr>
                                                <td class="left">Formato <a href="http://www.sbc.org.br/index.php?language=1&subject=60&content=downloads" target="_blank">SBC</a>, máximo 2 páginas.</td>
                                            </tr>
                                            <tr>
                                                <td width="100" class="left" valign="top" ><label><input name="arquivoAbst" type="file" /></label></td>
                                                <td class="right">&nbsp;</td>
                                            </tr>
                                        </table>
                                        <tr align= "center">
                                            <td width="100" class="left">&nbsp;</td>
                                            <td class="right">
                                                <input type="submit" class="btn" value="Enviar" />
                                                <input name="Reset" type="reset" class="btn" value="Limpar" />
                                            </td>
                                        </tr>
                                    </form>
                                </td>
                                <td class="midright" width="10">&nbsp;&nbsp;&nbsp;</td>
                            </tr>

                            <tr>
                                <td class="bottomleft" width="10" height="10">&nbsp;</td>
                                <td class="bottommid">&nbsp;</td>
                                <td class="bottomright" width="10" height="10">&nbsp;</td>
                            </tr>

                        </table>
                        <blockquote>&nbsp;</blockquote>
                    </div>
                </div>
            </div>
            <div style="clear: both;">&nbsp;</div>
        </div>
        <hr />
        <div id="footer">
            <p>&copy;2007 All Rights Reserved.&nbsp;&bull;&nbsp; Designed by <a href="http://www.freecsstemplates.org/" target="_blank">Free CSS Templates</a>.</p>
        </div>

    </body>
</html>
