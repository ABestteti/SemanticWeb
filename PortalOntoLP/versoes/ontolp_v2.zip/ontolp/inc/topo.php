<div id="header">
	<div id="menu">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="downloads.php">Recursos</a></li>
			
			<li><a href="sobre.php">Sobre</a></li>
			<li><a href="contato.php">Contato</a></li>
			<li><a href="links.php">Links</a></li>
		</ul>
	</div>
</div>

<div id="logo">
	<h1><a href="index.php">OntoLP</a></h1>
	<h2>Portal de Ontologia</h2>
</div>