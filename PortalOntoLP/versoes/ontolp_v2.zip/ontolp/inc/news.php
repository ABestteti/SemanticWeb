<div id="sidebar1" class="sidebar">
	<ul>
		<li id="recent-posts">
			<h2>Notícias</h2>
			<ul>
				<li>
				
					<h3><a href="http://www.inf.ufrgs.br/stil09/" target="_blank">STIL 2009 - 7º Simpósio Brasileiro em Tecnologia da Informação e da Linguagem Humana</a> <br /></h3>
					<p align="left">Data: 07/09/09 - 11/09/09</p>
					
					<h3><a href="http://www.inf.ufrgs.br/ER2009/" target="_blank">28ª Conferência Internacional sobre Modelagem Conceitual</a> <br />					
					</h3>
					<p align="left">Data: 09/11/09 - 12/11/09</p>
					
						
					
					
					
					
					<p align="center"><a href="noticias.php" target="_self">Mais Notícias</a></p>
				</li>
			</ul>
		</li>
	</ul>
</div>