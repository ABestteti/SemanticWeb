/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ontolpomvr;

// Java Imports
import java.io.PrintStream.*;
import java.io.InputStream;

// Jena API  Imports
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.rdf.model.*;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.graph.Graph;

/**
 *
 * @author Anderson Bestteti
 * 
 */
public class Main {

    static Model ontInput;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        boolean     isOWL;
        String      fileName;
        InputStream fp;

        fileName = (String)"file:"+args[0];

        isOWL = fileName.endsWith(".owl");

        if ((fp = FileManager.get().open(fileName)) == null)
        {
            throw new IllegalArgumentException("File: "+fileName+" not found.");
        }

        ontInput = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM);
        //        (isOWL ? OntModelSpec.OWL_MEM : OntModelSpec.RDFS_MEM,OntModelSpec.DAML_MEM));

        ontInput.read(fileName);


        if (!ontInput.isEmpty())
        {
            System.out.println("The Class is not empty...");
            Graph g = ontInput.getGraph();

            int ig = g.size();
            System.out.println("Size "+ig);
        }

    }

}
